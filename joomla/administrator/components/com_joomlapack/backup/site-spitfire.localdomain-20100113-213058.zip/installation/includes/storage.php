<?php
/**
 * @package JoomlaPack
 * @subpackage Installer
 * @copyright Copyright (C) 2009 JoomlaPack Developers. All rights reserved.
 * @author Nicholas K. Dionysopoulos - http://www.dionysopoulos.me
 * @version 4.0
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL v3 or later
 *
 * JoomlaPack Installer 4 temporary storage
 */

defined('_JPI') or die('Direct access is not allowed');

class JPStorage
{
	/**
	 * Chooses the data storage method (file/session)
	 * @var string
	 */
	var $_method;

	/**
	 * Where temporary data is stored when using file storage
	 * @var string
	 */
	var $_storagefile;

	/**
	 * The temporary data, as an associative array
	 * @var array
	 */
	var $_data;

	/**
	 * Singleton implementation
	 * @return JPStorage
	 */
	function &getInstance()
	{
		static $instance;

		if(empty($instance))
		{
			$instance = new JPStorage();
		}

		return $instance;
	}

	function JPStorage()
	{
		$storagefile = JPATH_INSTALLATION.DS.'storagedata.php';
		$this->_storagefile = $storagefile;

		// Can we read/write storagedata.php in the installation root?
		if( file_exists($storagefile) )
		{
			$file_available = @is_writable( $storagefile );
		}
		else
		{
			$file_available = @touch($storagefile);
		}

		$this->_method = $file_available ? 'file' : 'session';

		$this->loadData();
	}
	
	/**
	 * Is the storage class able to save the data between page loads?
	 * @return bool True if everything works properly
	 */
	function isStorageWorking()
	{
		switch($this->_method)
		{
			case 'file':
				return @is_writable($this->_storagefile);
				break;
				
			case 'session':
				return @is_writable(ini_get('session.save_path'));
				break;
		}

		return false;
	}

	/**
	 * Resets the internal storage
	 */
	function reset()
	{
		$this->_data = array();
	}

	/**
	 * Loads temporary data from a file or a session variable (auto detect)
	 */
	function loadData()
	{
		switch($this->_method)
		{
			case 'file':
				$this->_load_file();
				break;

			case 'session':
				$this->_load_session();
				break;
		}
	}

	/**
	 * Saves temporary data to a file or a session variable (auto detect)
	 */
	function saveData()
	{
		switch($this->_method)
		{
			case 'file':
				$this->_save_file();
				break;

			case 'session':
				$this->_save_session();
				break;
		}
	}

	/**
	 * Sets or updates the value of a temporary variable
	 * @param $key string The variable's name
	 * @param $value string The value to store
	 */
	function set($key, $value)
	{
		$this->_data[$key] = $value;
	}

	/**
	 * Returns the value of a temporary variable
	 * @param $key string The variable's name
	 * @param $default mixed The default value, null if not specified
	 * @return mixed The variable's value
	 */
	function get($key, $default = null)
	{
		if(array_key_exists($key, $this->_data))
		{
			return $this->_data[$key];
		}
		else
		{
			return $default;
		}
	}
	
	/**
	 * Removes a variable from the storage
	 * @param $key string The name of the variable to remove 
	 */
	function remove($key)
	{
		if(array_key_exists($key, $this->_data))
		{
			unset($this->_data[$key]);
		}
	}

	/**
	 * Loads temporary data from a file
	 */
	function _load_file()
	{
		$raw_data = file($this->_storagefile);
		if( count($raw_data) >= 2 )
		{
			$data = $raw_data[1];
			$this->decode_data($data);
		}
		else
		{
			$this->_data = array();
		}
	}

	/**
	 * Saves temporary data to a file
	 */
	function _save_file()
	{
		$data = $this->encode_data();
		$data = "<?php die('Access denied'); /*\n".$data."\n*/ ?>";
		if(function_exists('file_put_contents'))
		{
			@file_put_contents($this->_storagefile, $data);
		}
		else
		{
			$fp = @fopen($this->_storagefile,'w');
			@fwrite($fp, $data);
			@fclose($fp);
		}
	}

	/**
	 * Loads temporary data from a session variable
	 */
	function _load_session()
	{
		session_start();
		if( isset($_SESSION['jpi4data']) )
		{
			$data = $_SESSION['jpi4data'];
		}
		else
		{
			$data = '';
		}
		$this->decode_data($data);
	}

	/**
	 * Saves temporary data to a session variable
	 */
	function _save_session()
	{
		$_SESSION['jpi4data'] = $this->encode_data();
		session_write_close();
	}

	/**
	 * Returns a serialized form of the temporary data
	 * @return string The serialized data
	 */
	function encode_data()
	{
		$data = serialize($this->_data);
		return $data;
	}

	/**
	 * Loads the temporary data off their serialized form
	 * @param $data
	 */
	function decode_data($data)
	{
		$this->_data = array();
		$temp = @unserialize($data);
		if($temp !== false) $this->_data = $temp;
	}
}