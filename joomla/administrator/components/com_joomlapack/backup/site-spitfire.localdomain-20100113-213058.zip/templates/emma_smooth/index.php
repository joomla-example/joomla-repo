<?php
defined( '_JEXEC' ) or die( 'Restricted index access' );
define( 'TEMPLATEPATH', dirname(__FILE__) );
/*
-----------------------------------------
Emma Smooth - August 2009 Shape 5 Club Template
-----------------------------------------
Site:      www.shape5.com
Email:     contact@shape5.com
@license:  Copyrighted Commercial Software
@copyright (C) 2009 Shape 5

*/

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head" />

<?php

//
///////////////////////////////////////////////////////////////////////////////////////

	
		$s5_body_width = $this->params->get ("xml_s5_body_width");
		$s5_right_width = $this->params->get ("xml_s5_right_width");
		$s5_inset_width = $this->params->get ("xml_s5_inset_width");
		$s5_inset_pos = $this->params->get ("xml_s5_inset_pos");
		$s5_menu = $this->params->get ("xml_s5_menu");     
		$s5_lytebox = $this->params->get ("xml_s5_lytebox");  
		$s5_tooltips = $this->params->get ("xml_s5_tooltips");  
		$s5_show_frontpage = $this->params->get ("xml_s5_frontpage");  
		$s5_urlforSEO = $this->params->get ("xml_s5_seourl");
		$s5_top_menu_color = $this->params->get ("xml_s5_top_menu_color");
		$s5_highlight_color = $this->params->get ("xml_s5_highlight_color");
		$s5_text_menu_1 = $this->params->get ("xml_s5_text_menu_1");
		$s5_text_menu_2 = $this->params->get ("xml_s5_text_menu_2");
		$s5_text_menu_3 = $this->params->get ("xml_s5_text_menu_3");
		$s5_text_menu_4 = $this->params->get ("xml_s5_text_menu_4");
		$s5_text_menu_5 = $this->params->get ("xml_s5_text_menu_5");
		$s5_text_menu_6 = $this->params->get ("xml_s5_text_menu_6");
		$s5_text_menu_7 = $this->params->get ("xml_s5_text_menu_7");
		$s5_text_menu_8 = $this->params->get ("xml_s5_text_menu_8");
		$s5_text_menu_9 = $this->params->get ("xml_s5_text_menu_9");
		$s5_text_menu_10 = $this->params->get ("xml_s5_text_menu_10");
		$s5_open_text = $this->params->get ("xml_s5_open_text");
		$s5_closed_text = $this->params->get ("xml_s5_closed_text"); 
		$s5_open_start = $this->params->get ("xml_s5_open_start"); 
		$s5_direction = $this->params->get ("xml_s5_direction"); 
		


// It is recommended that you do not edit below this line.
///////////////////////////////////////////////////////////////////////////////////////


if (($s5_menu  == "1") || ($s5_menu  == "2") || ($s5_menu  == "3")){ 
require( TEMPLATEPATH.DS."s5_no_moo_menu.php");
}
else if ($s5_menu  == "4")  {
require( TEMPLATEPATH.DS."s5_suckerfish.php");
}
$menu_name = $this->params->get ("xml_menuname");

if ($s5_urlforSEO  == ""){ 
$LiveSiteUrl = JURI::base();}
if ($s5_urlforSEO  != ""){ 
$LiveSiteUrl = "$s5_urlforSEO/";}

$br = strtolower($_SERVER['HTTP_USER_AGENT']); // what browser.

$browser = "other";

if(ereg("msie 6", $br)) {
$browser = "ie6";
} 

else if(ereg("msie 7", $br)) {
$browser = "ie7";
} 

else if(ereg("msie 8", $br)) {
$browser = "ie8";
} 


// Drop Down Calculations

if ($this->countModules("drop_down_1") && $this->countModules("drop_down_2")  && $this->countModules("drop_down_3")) { $rowdd="33.3%"; }
else if ($this->countModules("drop_down_1") && $this->countModules("drop_down_2") && !$this->countModules("drop_down_3")) { $rowdd="49.9%"; }
else if ($this->countModules("drop_down_1") && !$this->countModules("drop_down_2") && $this->countModules("drop_down_3")) { $rowdd="49.9%"; }
else if (!$this->countModules("drop_down_1") && $this->countModules("drop_down_2") && $this->countModules("drop_down_3")) { $rowdd="49.9%"; }
else if ($this->countModules("drop_down_1") && !$this->countModules("drop_down_2") && !$this->countModules("drop_down_3")) { $rowdd="100%"; }
else if (!$this->countModules("drop_down_1") && $this->countModules("drop_down_2") && !$this->countModules("drop_down_3")) { $rowdd="100%"; }
else if (!$this->countModules("drop_down_1") && !$this->countModules("drop_down_2") && $this->countModules("drop_down_3")) { $rowdd="100%"; }

// Module size calculations

if(!$this->countModules('inset')) {
$s5_inset_width = "0";	
}

if(!$this->countModules('right')) {
$s5_right_width = "0";	
}

if ($this->countModules("bottom_row_1") && $this->countModules("bottom_row_2") && $this->countModules("bottom_row_3") && $this->countModules("bottom_row_4")) { $bot_row="24.9%"; }
else if (!$this->countModules("bottom_row_1") && $this->countModules("bottom_row_2") && $this->countModules("bottom_row_3") && $this->countModules("bottom_row_4")) { $bot_row="33.3%"; }
else if ($this->countModules("bottom_row_1") && !$this->countModules("bottom_row_2") && $this->countModules("bottom_row_3") && $this->countModules("bottom_row_4")) { $bot_row="33.3%"; }
else if ($this->countModules("bottom_row_1") && $this->countModules("bottom_row_2") && !$this->countModules("bottom_row_3") && $this->countModules("bottom_row_4")) { $bot_row="33.3%"; }
else if ($this->countModules("bottom_row_1") && $this->countModules("bottom_row_2") && $this->countModules("bottom_row_3") && !$this->countModules("bottom_row_4")) { $bot_row="33.3%"; }
else if (!$this->countModules("bottom_row_1") && !$this->countModules("bottom_row_2") && $this->countModules("bottom_row_3") && $this->countModules("bottom_row_4")) { $bot_row="49.9%"; }
else if (!$this->countModules("bottom_row_1") && $this->countModules("bottom_row_2") && !$this->countModules("bottom_row_3") && $this->countModules("bottom_row_4")) { $bot_row="49.9%"; }
else if (!$this->countModules("bottom_row_1") && $this->countModules("bottom_row_2") && $this->countModules("bottom_row_3") && !$this->countModules("bottom_row_4")) { $bot_row="49.9%"; }
else if ($this->countModules("bottom_row_1") && !$this->countModules("bottom_row_2") && !$this->countModules("bottom_row_3") && $this->countModules("bottom_row_4")) { $bot_row="49.9%"; }
else if ($this->countModules("bottom_row_1") && !$this->countModules("bottom_row_2") && $this->countModules("bottom_row_3") && !$this->countModules("bottom_row_4")) { $bot_row="49.9%"; }
else if ($this->countModules("bottom_row_1") && $this->countModules("bottom_row_2") && !$this->countModules("bottom_row_3") && !$this->countModules("bottom_row_4")) { $bot_row="49.9%"; }
else if (!$this->countModules("bottom_row_1") && !$this->countModules("bottom_row_2") && !$this->countModules("bottom_row_3") && $this->countModules("bottom_row_4")) { $bot_row="100%"; }
else if (!$this->countModules("bottom_row_1") && $this->countModules("bottom_row_2") && !$this->countModules("bottom_row_3") && !$this->countModules("bottom_row_4")) { $bot_row="100%"; }
else if (!$this->countModules("bottom_row_1") && !$this->countModules("bottom_row_2") && $this->countModules("bottom_row_3") && !$this->countModules("bottom_row_4")) { $bot_row="100%"; }
else if ($this->countModules("bottom_row_1") && !$this->countModules("bottom_row_2") && !$this->countModules("bottom_row_3") && !$this->countModules("bottom_row_4")) { $bot_row="100%"; }


?>

<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />
<meta http-equiv="Content-Style-Type" content="text/css" />

<link rel="stylesheet" href="<?php echo $LiveSiteUrl;?>/templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $LiveSiteUrl;?>/templates/system/css/general.css" type="text/css" />

<link href="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/css/template_css.css" rel="stylesheet" type="text/css" media="screen" />

<link href="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/css/s5_suckerfish.css" rel="stylesheet" type="text/css" media="screen" />

<link href="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/css/editor.css" rel="stylesheet" type="text/css" media="screen" />

<link href="/emma_smooth/templates/emma_smooth/favicon.ico" rel="shortcut icon" type="image/x-icon" />

<script type="text/javascript" language="javascript" src="<?php echo $this->baseurl ?>/templates/emma_smooth/js/s5_effects.js"></script>

<?php if($this->countModules('drop_down_1') || $this->countModules('drop_down_2') || $this->countModules('drop_down_3')) { ?>

	<script type="text/javascript" language="javascript" src="<?php echo $this->baseurl ?>/templates/emma_smooth/js/s5_cookies.js"></script>

<?php } ?>

<?php 
  $s5_domain = $_SERVER['HTTP_HOST']; $s5_path = $_SERVER['SCRIPT_NAME']; $s5_queryString = $_SERVER['QUERY_STRING']; $s5_url = "http://" . $s5_domain . $_SERVER['REQUEST_URI']; $s5_check_vm = strrpos($s5_url,"virtuemart");
  if ($s5_lytebox  == "yes") { 
  if ($s5_check_vm == "") {
?>
		<link rel="stylesheet" href="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/css/lytebox.css" type="text/css" media="screen" />
		<script type="text/javascript" language="javascript" src="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/js/lytebox.js"></script>
<?php } } ?>

<?php { 
echo "<script language=\"javascript\" type=\"text/javascript\" >var s5_text_menu_1 = '".$s5_text_menu_1."';</script>";
echo "<script language=\"javascript\" type=\"text/javascript\" >var s5_text_menu_2 = '".$s5_text_menu_2."';</script>";
echo "<script language=\"javascript\" type=\"text/javascript\" >var s5_text_menu_3 = '".$s5_text_menu_3."';</script>";
echo "<script language=\"javascript\" type=\"text/javascript\" >var s5_text_menu_4 = '".$s5_text_menu_4."';</script>";
echo "<script language=\"javascript\" type=\"text/javascript\" >var s5_text_menu_5 = '".$s5_text_menu_5."';</script>";
echo "<script language=\"javascript\" type=\"text/javascript\" >var s5_text_menu_6 = '".$s5_text_menu_6."';</script>";
echo "<script language=\"javascript\" type=\"text/javascript\" >var s5_text_menu_7 = '".$s5_text_menu_7."';</script>";
echo "<script language=\"javascript\" type=\"text/javascript\" >var s5_text_menu_8 = '".$s5_text_menu_8."';</script>";
echo "<script language=\"javascript\" type=\"text/javascript\" >var s5_text_menu_9 = '".$s5_text_menu_9."';</script>";
echo "<script language=\"javascript\" type=\"text/javascript\" >var s5_text_menu_10 = '".$s5_text_menu_10."';</script>";
}?>

<?php if($browser == "ie6" || $browser == "ie7" && $s5_menu != "5") { ?>

<script type="text/javascript" src="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/js/IEsuckerfish.js"></script>

<?php } ?>

<style type="text/css"> 

#s5_banner, #s5_banner ul.menu a, #s5_banner ul.menu a:visited {
color:#<?php echo $s5_top_menu_color ?>;
}

table.s5_newsflash_body a.readon, a, label, a:hover, a:focus, a:visited, #s5_button_content div.moduletable h3, .componentheading, #s5_navv a:hover, #s5_navv a.sfhover, .s5_h3_first, .contentheading, #s5_main_body_outer ul.menu #current a, #s5_main_body_outer ul.menu a:hover {
color:#<?php echo $s5_highlight_color ?>;
}

#s5_navv ul li.active a.active, .button {
background-color:#<?php echo $s5_highlight_color ?>;
}

<?php if ($browser == "ie6") { ?>

* html .button {
	background:#<?php echo $s5_highlight_color ?>;
}

* html #s5_logo_banner_wrap {
	background:none;
	filter:progid:dximagetransform.microsoft.alphaimageloader(src='<?php echo $LiveSiteUrl;?>/templates/emma_smooth/images/s5_logo.png', sizingmethod='crop');}
}

* html .s5_shadow {
	background:none;
	filter:progid:dximagetransform.microsoft.alphaimageloader(src='<?php echo $LiveSiteUrl;?>/templates/emma_smooth/images/s5_shadow.png', sizingmethod='crop');}
}

* html #s5_panel_top {
	background:none;
	filter:progid:dximagetransform.microsoft.alphaimageloader(src='<?php echo $LiveSiteUrl;?>/templates/emma_smooth/images/s5_shadow.png', sizingmethod='crop');}
}

* html #s5_panel_button {
	background:none;
	filter:progid:dximagetransform.microsoft.alphaimageloader(src='<?php echo $LiveSiteUrl;?>/templates/emma_smooth/images/s5_tab.png', sizingmethod='crop');}
}

#s5_bottom_row_1_mod, #s5_bottom_row_2_mod, #s5_bottom_row_3_mod, #s5_bottom_row_4_mod {
	overflow:hidden;
}

<?php } ?>

<?php if ($browser == "ie6" || $browser == "ie7") { ?>

.button {
padding-left:2px;
padding-right:2px;
}

<?php } ?>

<?php if ($s5_inset_pos == "2") { ?>

#s5_inset_column {
float:left;
}

#s5_body_column {
float:right;
}

<?php } ?>

</style> 

</head>

<body id="s5_body">

	<div id="s5_header_wrap" style="width:<?php echo $s5_body_width ?>px">
	
		<div id="s5_logo_banner_wrap" style="width:<?php echo $s5_body_width ?>px">
		
			<?php if($this->countModules('banner')) { ?>
									
				<div id="s5_banner">
					
					<jdoc:include type="modules" name="banner" style="notitle" />
										
				</div>
										
			<?php } ?>
		
		</div>
		
		<?php if($this->countModules('top_1')) { ?>
		
		<div id="s5_top_mod_wrap" style="width:<?php echo $s5_body_width ?>px">
		
			<div id="s5_top_mod_wrap_inner">
		
				<?php if($this->countModules('top_1')) { ?>
						
					<jdoc:include type="modules" name="top_1" style="notitle" />
											
				<?php } ?>
				
				<div style="clear:both"></div>
				
			</div>
			
			<div style="clear:both"></div>
		
		</div>
		
		<?php } ?>
		
		<?php if ($s5_menu  != "5") { ?>
		
			<div id="s5_menu">
				
				<div id="s5_navv">
									
					<?php mosShowListMenu($menu_name);	?>
						<?php if ($s5_menu  == "1") { ?>
							<script type="text/javascript" src="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/js/s5_drop_in_no_moo_menu.js"></script>																		
						<?php } ?>
						<?php if ($s5_menu  == "2") { ?>
							<script type="text/javascript" src="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/js/s5_fading_no_moo_menu.js"></script>																		
						<?php } ?>	
						<?php if ($s5_menu  == "3") { ?>
							<script type="text/javascript" src="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/js/s5_scroll_down_no_moo_menu.js"></script>																		
						<?php } ?>	
						<?php if ($s5_menu  == "4") { ?>
							<script type="text/javascript" src="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/js/s5_suckerfish.js"></script>																		
						<?php } ?>	
						<script type="text/javascript" src="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/js/s5_textmenu.js"></script>
									
				</div>
				
			</div>
						
		<?php } ?>
	
	</div>
	
	<?php if($this->countModules('top_1') || $s5_menu  == "1" || $s5_menu  == "2" || $s5_menu  == "3" || $s5_menu  == "4") { ?>
	
		<div class="s5_shadow" style="width:<?php echo $s5_body_width ?>px<?php if($this->countModules('drop_down_1') || $this->countModules('drop_down_2') || $this->countModules('drop_down_3')) { ?>; margin-bottom:0px<?php } ?>"></div>
	
	<?php } ?>
	
	<!-- Start Slider Panel -->
				
		<?php if($this->countModules('drop_down_1') || $this->countModules('drop_down_2') || $this->countModules('drop_down_3')) { ?>

					<form name="s5_panelform" action="" id="panelform">

						<input type="hidden" id="panel_holder" name="panel_holder" value=""></input>

						<script type="text/javascript">

							load_valuepanel();

						</script>

					</form>

				   <div id="s5_panel" style="width:<?php echo $s5_body_width ?>px">

						<div id="s5_panel_inner">

							<div id="s5_panel_top"></div>
							
								<div style="padding-left:13px; padding-right:13px">
						  
										  <?php if ($this->countModules("drop_down_1")) { ?><div style="width:<?php echo $rowdd; ?>; float: left;"><div class="rowpadding"><jdoc:include type="modules" name="drop_down_1" style="xhtml" /></div></div><?php } ?>

										  <?php if ($this->countModules("drop_down_2")) { ?><div style="width:<?php echo $rowdd; ?>; float: left;"><div class="rowpadding"><jdoc:include type="modules" name="drop_down_2" style="xhtml" /></div></div><?php } ?>

										  <?php if ($this->countModules("drop_down_3")) { ?><div style="width:<?php echo $rowdd; ?>; float: left;"><div class="rowpadding"><jdoc:include type="modules" name="drop_down_3" style="xhtml" /></div></div><?php } ?>

								</div>
							
							<div class="clr"></div>

							<div style="clear:both"></div>

							<div id="s5_panel_bottom"></div>

						</div>

				   </div>

					<div style="clear:both"></div>

					<div id="s5_panel_button" onclick="panel()">
							<div id="s5_open"<?php if ($s5_open_start == "open") { ?> style="display:none;"<?php } ?>><?php echo $s5_open_text; ?></div>
							<div id="s5_closed"<?php if ($s5_open_start == "closed") { ?> style="display:none;"<?php } ?>><?php echo $s5_closed_text; ?></div>
					</div>
		  
		<?php } ?> 
			
	<!-- End Slider Panel -->
	
	<div id="s5_bottom_wrap" style="width:<?php echo $s5_body_width ?>px">
	
		<div class="s5_bar">
		
						<?php if($this->countModules('breadcrumb')) { ?>
						
							<div id="s5_pathway">
							
								<jdoc:include type="modules" name="breadcrumb" style="notitle" />
							
							</div>
						
						<?php } ?>
						
						<?php if($this->countModules('search') || $this->countModules('login')) { ?>
						
							<div id="s5_sl_wrap">
						
								<?php if($this->countModules('search')) { ?>
										
										<div id="s5_search">
									
											<jdoc:include type="modules" name="search" style="notitle" />
											
										</div>
										
								<?php } ?>
										
								<?php if($this->countModules('login')) { ?>
										
										<div id="s5_login">
									
											<jdoc:include type="modules" name="login" style="notitle" />
											
										</div>
								
								<?php } ?>
								
							</div>
							
						<?php } ?>
					
					<div style="clear:both"></div>
		
		</div>
		
		<div id="s5_main_body_outer">
		
			<div id="s5_content_area" style="width:<?php echo $s5_body_width - $s5_right_width ?>px">
			
				<div id="s5_content_area_inner">
				
					<?php if($this->countModules('above_body_1')) { ?>
									
						<div id="s5_right_above_body_1" style="margin-right:10px; float:left; width:<?php echo ($s5_body_width  - $s5_right_width)/2 - 16 ?>px">
							
							<div id="s5_right_above_body_1_inner">
										
								<jdoc:include type="modules" name="above_body_1" style="round_box" />
								
							</div>

						</div>	
										
					<?php } ?>
					
					<?php if($this->countModules('above_body_2')) { ?>
									
						<div id="s5_right_above_body_2" style="float:right; width:<?php echo ($s5_body_width  - $s5_right_width)/2 - 16 ?>px">
										
							<div id="s5_right_above_body_2_inner">
										
								<jdoc:include type="modules" name="above_body_2" style="round_box" />
								
							</div>

						</div>	
										
					<?php } ?>
					
					<?php if($this->countModules('above_body_1') || $this->countModules('above_body_2')) { ?>
						
						<div style="clear:both"></div>
						<div class="s5_top_mod_sep"></div>
					
					<?php } ?>
			
					<?php if($this->countModules('above_body_3')) { ?>
					
					<div style="clear:both"></div>
									
						<div id="s5_right_above_body_3">
										
							<div id="s5_right_above_body_3_inner">
										
								<jdoc:include type="modules" name="above_body_3" style="round_box" />
								
							</div>

						</div>	
										
					<?php } ?>
					
					<?php if($this->countModules('above_body_3')) { ?>
					
						<div class="s5_top_mod_sep"></div>
					
					<?php } ?>

					<?php 
							$s5_frontpage = "yes"; 
							$s5_current_page = ""; 
							if (JRequest::getVar('view') == "frontpage") {
								$s5_current_page = "frontpage";
							}
							if (JRequest::getVar('view') != "frontpage") {
								$s5_current_page = "not_frontpage";
							}
							if ($s5_show_frontpage == "no" && $s5_current_page == "frontpage") {
								$s5_frontpage = "no";
							}
							$s5_check_frontpage = strrpos($s5_url,"index.php");
							if ($s5_check_frontpage > 1) {
								$s5_frontpage = "not_frontpage";
							} ?>
											
							<?php if ($s5_frontpage != "no") { ?>
							
								<?php if($this->countModules('inset')) { ?>
								<div id="s5_body_column" style="width:<?php echo $s5_body_width - $s5_right_width - $s5_inset_width - 32 ?>px">
								<?php } ?>
								<?php if(!$this->countModules('inset')) { ?>
								<div id="s5_body_column" style="width:<?php echo $s5_body_width - $s5_right_width - $s5_inset_width - 22 ?>px">
								<?php } ?>
								<div id="s5_body_column_inner">
						
									<jdoc:include type="message" />
									<jdoc:include type="component" />
									
								</div>
								</div>
								
								<?php if($this->countModules('inset')) { ?>
									
									<div id="s5_inset_column" style="width:<?php echo $s5_inset_width ?>px">
									<div id="s5_inset_column_inner">
									
										<jdoc:include type="modules" name="inset" style="round_box" />
									
									</div>
									</div>
									
								<?php } ?>
								
							<?php } ?>
							
					<div style="clear:both"></div>
			
				</div>
			
			</div>
			
			<?php if($this->countModules('right')) { ?>
			
				<div id="s5_right_column" style="width:<?php echo $s5_right_width ?>px">
				
					<div id="s5_right_column_inner">
				
						<jdoc:include type="modules" name="right" style="round_box" />
				
					</div>
				
				</div>
				
			<?php } ?>
			
			<div style="clear:both"></div>
		
		</div>
		
		<div class="s5_shadow" style="width:<?php echo $s5_body_width ?>px"></div>
		
		<?php if($this->countModules('bottom_row_1') || $this->countModules('bottom_row_2') || $this->countModules('bottom_row_3') || $this->countModules('bottom_row_4')) { ?>
		
			<div class="s5_bar"></div>
			
				<div id="s5_row1">
				<div id="s5_row1_inner">	
					
									<?php if($this->countModules('bottom_row_1')) { ?>
									<div id="s5_bottom_row_1_mod" style="width:<?php echo $bot_row ?>">
									<div id="s5_bottom_row_1_inner_mod"<?php if($this->countModules('bottom_row_2') || $this->countModules('bottom_row_3') || $this->countModules('bottom_row_4')) { ?> style="padding-right:14px"<?php } ?>>
										<jdoc:include type="modules" name="bottom_row_1" style="round_box" />
									</div>
									</div>
									<?php } ?> 
									<?php if($this->countModules('bottom_row_2')) { ?>
									<div id="s5_bottom_row_2_mod" style="width:<?php echo $bot_row ?>">
									<div id="s5_bottom_row_2_inner_mod"<?php if($this->countModules('bottom_row_3') || $this->countModules('bottom_row_4')) { ?> style="padding-right:14px"<?php } ?>>
										<jdoc:include type="modules" name="bottom_row_2" style="round_box" />
										<div style="clear:both"></div>
									</div>
									</div>
									<?php } ?> 
									<?php if($this->countModules('bottom_row_3')) { ?>
									<div id="s5_bottom_row_3_mod" style="width:<?php echo $bot_row ?>">
									<div id="s5_bottom_row_3_inner_mod"<?php if($this->countModules('bottom_row_4')) { ?> style="padding-right:14px"<?php } ?>>
										<jdoc:include type="modules" name="bottom_row_3" style="round_box" />
										<div style="clear:both"></div>
									</div>
									</div>
									<?php } ?> 
									<?php if($this->countModules('bottom_row_4')) { ?>
									<div id="s5_bottom_row_4_mod" style="width:<?php echo $bot_row ?>">
									<div id="s5_bottom_row_4_inner_mod">
										<jdoc:include type="modules" name="bottom_row_4" style="round_box" />
										<div style="clear:both"></div>
									</div>
									</div>
									<?php } ?> 
									
									<div style="clear:both"></div>
					
				</div>
				<div style="clear:both"></div>
				</div>
			
			<div class="s5_shadow" style="width:<?php echo $s5_body_width ?>px"></div>
		
		<?php } ?> 
		
			<div class="s5_bar" style="width:<?php echo $s5_body_width ?>px">
				
				<div id="s5_footer">
		
					<div id="s5_footer_inner" style="width:<?php echo $s5_body_width ?>px">
				
						<div id="s5_footer_text">
							<?php include("templates/emma_smooth/footer.php"); ?>
						</div>
						<div id="s5_bottom_pos">
							<jdoc:include type="modules" name="bottom_menu" style="notitle" />
						</div>	
						
						<div style="clear:both"></div>
						
					</div>
				
				</div>
			
			</div>
				
			<div class="s5_shadow" style="width:<?php echo $s5_body_width ?>px"></div>
			
			<div style="height:20px"></div>
		
	</div>
	
	<?php if ($s5_tooltips  == "yes") { ?>
	<script type="text/javascript" language="javascript" src="<?php echo $LiveSiteUrl;?>/templates/emma_smooth/js/tooltips.js"></script>
	<?php } ?>
	
	<?php if($this->countModules('debug')) { ?>
		<div style="color:#FFFFFF">
			<jdoc:include type="modules" name="debug" style="xhtml" />
		</div>
	<?php } ?>
	
	<script type="text/javascript">

		<?php if($this->countModules('drop_down_1') || $this->countModules('drop_down_2') || $this->countModules('drop_down_3')) { ?>

			var panelholder = document.getElementById("s5_panel_inner").offsetHeight;

		<?php if ($s5_open_start == "open") { ?>

			 if (document.getElementById("panel_holder").value == "" || document.getElementById("panel_holder").value == " " || document.getElementById("panel_holder").value == "undefined") {

				  panel();
			 }

		<?php } ?>

			 if (document.getElementById("panel_holder").value == "1") {

				  document.getElementById("s5_panel").style.height = panelholder +'px';
				  panelclick = 1;
			 }

			 if (document.getElementById("panel_holder").value == "2") {

				  document.getElementById("s5_panel").style.height = 0 +'px';
				  panelclick = 0;
				  document.getElementById("s5_open").style.display = 'block'; 
				  document.getElementById("s5_closed").style.display = 'none'; 
			 }

		<?php } ?>

	</script>
	

</body>

</html>