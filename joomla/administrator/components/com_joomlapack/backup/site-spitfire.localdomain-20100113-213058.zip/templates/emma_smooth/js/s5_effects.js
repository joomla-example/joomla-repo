
var panelclick = 0;
var panelbig = 0;
var panelboxbig = 0;

var panelsmall = 0;
var panelboxsmall = 0;
var boxheightquery = 0;


function panel() {

if (panelclick == 0) {
panel3();
document.getElementById("panel_holder").value = "1";
store_form_panel();
document.getElementById("s5_open").style.display = 'none'; 
document.getElementById("s5_closed").style.display = 'block'; 
}

if (panelclick == 1) {
panel4();
document.getElementById("panel_holder").value = "2";
store_form_panel();
document.getElementById("s5_open").style.display = 'block'; 
document.getElementById("s5_closed").style.display = 'none'; 
}

}



function panel3() {


if (panelboxbig >= panelholder) {
document.getElementById("s5_panel").style.height = panelholder +'px';
panelclick = 1;
panelboxbig = 0;
panelbig = 0;
}
else {
window.setTimeout('increasepanelbox()',50);
}
}


function increasepanelbox() {
document.getElementById("s5_panel").style.height = panelboxbig +'px';
panel3();
panelboxbig = panelboxbig + 20;
}


function panel4() {

if (document.getElementById("s5_panel").offsetHeight > 1)
{
window.setTimeout('decreasepanelbox()',50);
}

}

function decreasepanelbox() {

panelheightquery = document.getElementById("s5_panel").offsetHeight;
panelheightquery = panelheightquery*1;

document.getElementById("s5_panel").style.height = panelheightquery - 20 +'px';


if (document.getElementById("s5_panel").offsetHeight < 20) {
document.getElementById("s5_panel").style.height = '0px';
panelclick = 0;
}


panel4();
}


var s5_right_column_height = 0;
var s5_main_column_height = 0;

var s5_right_column_inner_height = 0;
var s5_main_column_inner_height = 0;

function s5_set_body_height() {
	if (document.getElementById("s5_right_column")) {
		if (document.getElementById("s5_content_area")) {
		
		if ((s5_right_column_inner_height != document.getElementById("s5_right_column_inner").offsetHeight) || (s5_main_column_inner_height != document.getElementById("s5_content_area_inner").offsetHeight)){
				document.getElementById("s5_content_area").style.height = "auto";
				document.getElementById("s5_right_column").style.height = "auto";
				s5_right_column_height = document.getElementById("s5_right_column").offsetHeight;
				s5_main_column_height = document.getElementById("s5_content_area").offsetHeight;
			
				if (s5_right_column_height > s5_main_column_height) {
					document.getElementById("s5_content_area").style.height = s5_right_column_height + "px";
				}
				
				if (s5_right_column_height < s5_main_column_height) {
					document.getElementById("s5_right_column").style.height = s5_main_column_height + "px";
				}
				
				s5_right_column_height = document.getElementById("s5_right_column").offsetHeight;
				s5_main_column_height = document.getElementById("s5_content_area").offsetHeight;
				
				s5_right_column_inner_height = document.getElementById("s5_right_column_inner").offsetHeight;
				s5_main_column_inner_height = document.getElementById("s5_content_area_inner").offsetHeight;
			}
			
		}
	}
}


var s5_body_Interval = 0;
s5_body_Interval = window.setInterval("s5_set_body_height()",200);
